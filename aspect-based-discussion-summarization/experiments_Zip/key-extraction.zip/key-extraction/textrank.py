from summa import keywords

with open('./art-23/data/article23.txt', 'r') as article_file:
    data=article_file.read()
    print '\nARTICLE ONLLY: \n {0}'.format(keywords.keywords(data))

with open('./art-23/data/comments.txt', 'r') as article_file:
    data=article_file.read()
    print '\nCOMMENT ONLLY: \n {0}'.format(keywords.keywords(data))

with open('./art-23/data/combine.txt', 'r') as article_file:
    data=article_file.read()
    print '\nCOMBINE: \n {0}'.format(keywords.keywords(data))

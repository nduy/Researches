from rake_nltk import Rake
from cucco import Cucco
import re
import string
printable = set(string.printable)

normalizations = [
    'remove_accent_marks',
    ('replace_urls', {'replacement': ''}),
    ('replace_emails', {'replacement': ''}),
    'remove_extra_whitespaces',
]


def text_preprocessing(rawText):
    # print  replace_pattern
    txt = cucco.normalize(rawText.decode('utf8', 'ignore'), normalizations)
    txt = re.sub('<\D*>.*?<\D*>', '', txt)
    m = re.search(r"[a-z]([.,;:<>()+])[A-Z]", txt) # Fix space missing typo
    txt = txt[:m.start()+2] + u" " + txt[m.end()-1:] if m else txt
    txt = filter(lambda x: x in printable, txt)
    return txt

def replace_all(repls, str):
    # return re.sub('|'.join(repls.keys()), lambda k: repls[k.group(0)], str)
    return re.sub('|'.join(re.escape(key) for key in repls.keys()),
                  lambda k: repls[k.group(0)], str)
          
cucco = Cucco()

with open('./art-23/data/article23.txt', 'r') as article_file:
    data=article_file.read()
    r = Rake()
    r.extract_keywords_from_text(text_preprocessing(data))
    print '\nARTICLE ONLLY: \n {0}'.format(r.get_ranked_phrases_with_scores())

with open('./art-23/data/comments.txt', 'r') as article_file:
    data=article_file.read()
    r = Rake()
    r.extract_keywords_from_text(text_preprocessing(data))
    print '\nCOMMENT ONLLY: \n {0}'.format(r.get_ranked_phrases())

with open('./art-23/data/combine.txt', 'r') as article_file:
    data=article_file.read()
    r = Rake()
    r.extract_keywords_from_text(text_preprocessing(data))
    print '\nCOMBINE: \n {0}'.format(r.get_ranked_phrases())

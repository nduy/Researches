import pke


extractor = pke.TopicRank(input_file='./art-23/data/article23.txt')
extractor.read_document(format='raw')
extractor.candidate_selection()
extractor.candidate_weighting()
print '\nARTICLE ONLLY: \n {0}'.format( extractor.get_n_best(n=80))

extractor = pke.TopicRank(input_file='./art-23/data/comments.txt')
extractor.read_document(format='raw')
extractor.candidate_selection()
extractor.candidate_weighting()
print '\nCOMMENT ONLLY: \n {0}'.format( extractor.get_n_best(n=80))

extractor = pke.TopicRank(input_file='./art-23/data/combine.txt')
extractor.read_document(format='raw')
extractor.candidate_selection()
extractor.candidate_weighting()
print '\n\nCOMBINE: \n {0}'.format( extractor.get_n_best(n=80))
# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import datetime
import time
QUERY_STATEMENT = 'http://140.203.154.194/dcaquery.php?BuyerID=DDN'
def queryAPI():
    r = requests.get(QUERY_STATEMENT, )

    #    print(r.status_code);
    #    print(r.headers['content-type'])
    elap_micro = r.elapsed.microseconds
    elap_mili = int(round(r.elapsed.microseconds / 1000))
#    print("$$$$Elapsed Time Microsecond: " + str(elap_micro))
#    print("$$$$Elapsed Time Milisecond: " + str(elap_mili))
    now = datetime.datetime.now()
    weekday_index= now.weekday();
    weekday= "Monday" if weekday_index==0 else\
        "Tuesday" if weekday_index==1 else\
            "Wednesday" if weekday_index==2 else\
                "Thursday" if weekday_index==3 else\
                    "Friday" if weekday_index==4 else "Sunday"
    day = now.day
    month =now.month
    year  =now.year
    hour = now.hour
    minute= now.minute
    second= now.second

    return("{0},{1},{2},{3},{4},{5},{6},{7},{8}".format(year,month,day,weekday,hour,minute,second,len(r.content),elap_mili))


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    to_listen_min= float(str(input("How long do you want to continuoysly query the API (minutes? ")))
    to_listen_sec=to_listen_min*60
    print("About to continuously query API for {0} second".format(to_listen_sec))
    now = datetime.datetime.now()
    filename = 'OutPut\{0}-{1}-{2}_{3}-{4}.csv'.format(now.year,now.month,now.day,now.hour,now.minute);
    print("File Name: "+ filename)
    f = open('OutPut\{0}-{1}-{2}_{3}-{4}.csv'.format(now.year,now.month,now.day,now.hour,now.minute), 'w')
    f.write("Year,Month,Day,Weekday,Hour,Minute,Second,ContentLength,ElapsedTimeMilisecond \n")

    t_end = time.time() + to_listen_sec
    while time.time() < t_end:
        f.write(queryAPI());
        f.write("\n")
        time.sleep(1);

        print("Connection refused by the server..")
        print("Let me sleep for 5 seconds")
        print("ZZzzzz...")
        time.sleep(5)
        print("Was a nice sleep, now let me continue...")
    f.close();
    '''   
    print_hi('PyCharm')
    r = requests.get('http://140.203.154.194/dcaquery.php?BuyerID=DDN', )
#    print(r.status_code);
#    print(r.headers['content-type'])
    elap_micro=r.elapsed.microseconds
    elao_mili=int(round(r.elapsed.microseconds /1000))
    print("$$$$Elapsed Time Microsecond: " + str(elap_micro))
    print("$$$$Elapsed Time Milisecond: "+str(elao_mili))
'''
# See PyCharm help at https://www.jetbrains.com/help/pycharm/

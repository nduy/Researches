MIDNIGHT BUILT version, NOT yet tested with real Pis
Executable script is "publish.py"<br/>
======= ==API==IMPORTANT: <br/>
Before running script, you must deploy an API in a server with PHP enabled.\
See here the following how to install it in Unix-like System:\
https://websiteforstudents.com/apache2-with-php-7-1-support-on-ubuntu-18-04-lts-beta-server/ \
Source code for API is in APIBuyerDCAStatusQuery. primarily call "dcaquery.php".\
=========DATABASE<br/>
Database file is in <br/>
Deltamart-Internal/Buyer-Template/Database/SQL/__
The name of the SQL file is the Table name.\
Everything is under the table of "miniproto"\
==========

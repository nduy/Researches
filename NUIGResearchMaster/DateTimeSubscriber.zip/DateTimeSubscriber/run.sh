python3 subscribe.py
